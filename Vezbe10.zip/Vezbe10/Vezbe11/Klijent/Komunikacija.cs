﻿using Domen;
using System;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;

namespace Klijent
{
    internal class Komunikacija
    {
        private static Komunikacija instance;
        private Socket soket;
        private NetworkStream tok;
        private BinaryFormatter formatter = new BinaryFormatter();
        private Komunikacija()
        {

        }
        public static Komunikacija Instance
        {
            get
            {
                if (instance == null) instance = new Komunikacija();
                return instance;
            }
        }


        private Thread nit;
        private bool kraj;

        public void PrijaviSe(string ime)
        {
            soket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            soket.Connect("127.0.0.1", 9000);
            tok = new NetworkStream(soket);
            Zahtev zahtev = new Zahtev { Objekat = new Korisnik { Ime = ime } };
            formatter.Serialize(tok, zahtev);
            Odgovor odg = (Odgovor)formatter.Deserialize(tok);
            if (odg.Signal == Signal.Err)
            {
                soket.Close();
                throw new Exception("Ime je zauzeto!");
            }
            
        }

        

        public void PosaljiPoruku(Zahtev z)
        {
            formatter.Serialize(tok, z);
        }

        internal void Zavrsi()
        {
            soket.Close();
        }

        public Odgovor ProcitajPorukuOdServera()
        {
            return (Odgovor)formatter.Deserialize(tok);
        }
    }
}