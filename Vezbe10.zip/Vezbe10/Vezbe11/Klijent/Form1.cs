﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class Form1 : Form
    {
        private bool kraj;
        private Korisnik korisnik;
        private Thread nit;

        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
            groupBox2.Enabled = false;
            // comboBox1.DataSource = (Tip[])Enum.GetValues(typeof(Tip));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                //textBox1.Text.All(char.IsDigit)
                //textBox1.Text.Any(char.IsDigit)
                // && textBox1.Text.Any(c=> c=='@')
                if (!string.IsNullOrEmpty(textBox1.Text))
                {
                    Komunikacija.Instance.PrijaviSe(textBox1.Text);
                    korisnik = new Korisnik { Ime = textBox1.Text };
                    nit = new Thread(PrimajPoruke);
                    nit.IsBackground = true;
                    nit.Start();
                    groupBox1.Enabled = false;
                    groupBox2.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Pogresan unos");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void PrimajPoruke()
        {
            kraj = false;
            while (!kraj)
            {
                try
                {
                    Odgovor o = Komunikacija.Instance.ProcitajPorukuOdServera();
                    switch (o.Signal)
                    {

                        case Signal.Kraj:
                            Kraj((string)o.Objekat);
                            Komunikacija.Instance.Zavrsi();
                            break;
                    }
                }
                catch (Exception e)
                {
                    kraj = true;
                }
            }
        }
        internal void Kraj(string poruka)
        {
            MessageBox.Show(poruka);
            groupBox1.Enabled = true;
            groupBox2.Enabled = false;
        }
    }
}
