﻿using Domen;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Timers;

namespace Server
{
    internal class Obrada2
    {
        private List<Obrada1> klijenti;
        private Server server;
        private Form1 form1;
        private Thread tajmer;
        public static AutoResetEvent arEvent = new AutoResetEvent(false);

        public Obrada2(List<Obrada1> klijenti)
        {
            this.klijenti = klijenti;
        }

        public Obrada2(List<Obrada1> klijenti, Form1 form1) : this(klijenti)
        {
            this.form1 = form1;
            TrajanjeIgre = 20;
        }

        public Action OsveziFormu { get; internal set; }
        public int TrajanjeIgre { get; private set; }
        public static string Rec { get; internal set; }

        internal void IgrajAsinhrono()
        {
            form1.UnesiRec();
            arEvent.WaitOne();
            // rec je setovana
            string rec = Rec;
            List<Thread> niti = new List<Thread>();
            klijenti.ForEach(k => niti.Add(new Thread(k.Igraj)));
            niti.ForEach(n => n.IsBackground = true);
            niti.ForEach(n => n.Start());
            tajmer = new Thread(Tajmer);
            tajmer.Start();

            niti.ForEach(n => n.Join());

        }

        private void Tajmer()
        {
            System.Timers.Timer timer = new System.Timers.Timer(TrajanjeIgre*1000);
            Stopwatch stopwatch = new Stopwatch();
            timer.AutoReset = false;
            timer.Elapsed += ZavrsiTajmer;
            timer.Start();
            stopwatch.Start();
            bool krajVremena = false;
            while (!krajVremena)
            {
                try
                {
                    form1.OsveziVremeProslo(stopwatch.Elapsed);
                    form1.OsveziVremeOstalo(new TimeSpan(0, 0, TrajanjeIgre) - stopwatch.Elapsed);
                    Thread.Sleep(1000);
                }
                catch (ThreadInterruptedException)
                {
                    krajVremena = true;
                    stopwatch.Stop();
                    form1.OsveziVremeProslo(new TimeSpan(0, 0, TrajanjeIgre));
                    form1.OsveziVremeOstalo(new TimeSpan(0));

                }
            }
        
    }

    
        private void ZavrsiTajmer(object sender, ElapsedEventArgs e)
        {
            tajmer.Interrupt();
            ZavrsiIgru();

        }

        private void ZavrsiIgru()
        {
            klijenti.ForEach(k => k.Salji(new Odgovor { Signal = Signal.Kraj, Objekat = "kraj" }));
        }

        internal void IgrajSinhrono()
        {
            List<Thread> niti = new List<Thread>();
            klijenti.ForEach(k => niti.Add(new Thread(k.Igraj)));
            niti.ForEach(n => n.IsBackground = true);
            niti.ForEach(n => n.Start());


            //niti.ForEach(n => n.Join());

        }

        public void RandomGenerator()
        {
            Random random = new Random();
            int broj = random.Next(10, 20);
            int broj2 = random.Next(10);
        }
    }
}