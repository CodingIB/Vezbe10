﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server
{
    public partial class Form1 : Form
    {
        private Server server;

        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
            groupBox1.Visible = false;
            server = new Server(this);
            button2.Enabled = false;
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                server.Pokreni();
                button1.Enabled = false;
                groupBox1.Visible = true;
                button2.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            server.Zavrsi();
            button1.Enabled = true;
            button2.Enabled = false;
        }
    }
}
