﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using Domen;

namespace Server
{
    internal class Obrada1
    {
        private Socket klijentskiSoket;
        private NetworkStream tok;
        private BinaryFormatter formatter;
        private bool kraj;

        public Obrada1(Socket k)
        {
            this.klijentskiSoket = k;

            tok = new NetworkStream(k);
            formatter = new BinaryFormatter();
        }

        public Korisnik Korisnik { get;  set; }
        public List<Obrada1> Klijenti { get; internal set; }

        internal Zahtev PrimiPoruku()
        {
            Zahtev z = (Zahtev)formatter.Deserialize(tok);
            return z;

        }
               

        internal void Igraj()
        {
            kraj = false;
            while (!kraj)
            {
                try
                {
                    Zahtev zahtev = PrimiPoruku();
                    switch (zahtev.Tip)
                    {
                        case Tip.Kraj:
                            Zavrsi();
                            break;
                    }
                }
                catch (IOException e)
                {
                    //kraj = true;
                    Zavrsi();
                }
            }
        }

        internal void Salji(Odgovor odgovor)
        {
            formatter.Serialize(tok, odgovor);
        }

        internal void Ugasi()
        {
            Salji(new Odgovor { Signal = Signal.KrajServer });
        }
        internal void Zavrsi()
        {
            Klijenti?.Remove(this);
            kraj = true;
            klijentskiSoket.Shutdown(SocketShutdown.Both);
            
            klijentskiSoket.Close();
        }
    }
}