﻿using Domen;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server
{
    public class Server
    {
        private Socket soket;
        private int brojKlijenata;
        private Thread nit;
        private List<Obrada2> obrada2;
        private bool kraj;
        private Form1 form1;
        private List<Obrada1> klijenti;

        public Server(Form1 form1)
        {
            this.form1 = form1;
        }

        public event Action OsveziFormu;

        internal bool Pokreni()
        {
            try
            {
                soket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                soket.Bind(new IPEndPoint(IPAddress.Parse("127.0.0.1"), 9000));
                soket.Listen(5);
                brojKlijenata = int.Parse(ConfigurationManager.AppSettings["brojIgraca"]);

                nit = new Thread(Osluskuj);
                nit.IsBackground = true;
                nit.Start();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        internal void Zavrsi()
        {
            if (klijenti.Count > 0)
                klijenti.ForEach(k => k.Zavrsi());
            obrada2.ForEach(o2 => o2.Zavrsi());
            soket.Close();

        }

        private void Osluskuj()
        {
            obrada2 = new List<Obrada2>();
            kraj = false;
            while (!kraj)
            {
                klijenti = new List<Obrada1>();
                int br = brojKlijenata;
                try
                {
                    while (br > 0)
                    {

                        Socket k = soket.Accept();
                        Obrada1 o1 = new Obrada1(k);
                        Zahtev z = o1.PrimiPoruku();
                        if (klijenti.Where(o => o?.Korisnik.Ime == ((Korisnik)z.Objekat).Ime).Count() > 0)
                            o1.Salji(new Odgovor { Signal = Signal.Err, Objekat = new object() });
                        else
                        {
                            o1.Korisnik = (Korisnik)z.Objekat;
                            o1.Salji(new Odgovor { Signal = Signal.Ok, Objekat = o1.Korisnik });
                            klijenti.Add(o1);
                            br--;
                        }

                    }

                    Obrada2 o2 = new Obrada2(klijenti, form1);
                    klijenti = new List<Obrada1>();
                    o2.OsveziFormu += OsveziFormu;
                    obrada2.Add(o2);
                    new Thread(o2.IgrajAsinhrono).Start();
                }
                catch (SocketException e)
                {
                    br = 0;
                    kraj = true;
                }
            }
        }

    }
}
