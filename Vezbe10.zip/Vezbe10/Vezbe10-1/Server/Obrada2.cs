﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Server
{
    internal class Obrada2
    {
        private List<Obrada1> klijenti;
        private Server server;
        private Form1 form1;

        public Obrada2(List<Obrada1> klijenti)
        {
            this.klijenti = klijenti;
            this.klijenti.ForEach(k => k.Klijenti = this.klijenti);
        }

        public Obrada2(List<Obrada1> klijenti, Form1 form1) : this(klijenti)
        {
            this.form1 = form1;
        }

        public Action OsveziFormu { get; internal set; }

        internal void IgrajAsinhrono()
        {
            List<Thread> niti = new List<Thread>();
            klijenti.ForEach(k => niti.Add(new Thread(k.Igraj)));
            niti.ForEach(n => n.IsBackground = true);
            niti.ForEach(n => n.Start());


            niti.ForEach(n => n.Join());

        }

        internal void IgrajSinhrono()
        {
            List<Thread> niti = new List<Thread>();
            klijenti.ForEach(k => niti.Add(new Thread(k.Igraj)));
            niti.ForEach(n => n.IsBackground = true);
            niti.ForEach(n => n.Start());


            //niti.ForEach(n => n.Join());

        }

        public void Zavrsi()
        {
            klijenti.ForEach(k => k.Ugasi());
        }
    }
}