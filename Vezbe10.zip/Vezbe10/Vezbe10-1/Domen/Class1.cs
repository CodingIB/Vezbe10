﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    public class Class1
    {
    }

    [Serializable]
    public class Zahtev
    {
        Tip tip;
        object objekat;

        public Tip Tip { get => tip; set => tip = value; }
        public object Objekat { get => objekat; set => objekat = value; }
    }

    public enum Tip
    {
        Prijava,
        Odg,
        Kraj
    }

    [Serializable]
    public class Odgovor
    {
        Signal tip;
        object objekat;

        public Signal Signal { get => tip; set => tip = value; }
        public object Objekat { get => objekat; set => objekat = value; }
    }
    [Serializable]
    public class Korisnik
    {
        public string Ime { get; set; }
    }

    public enum Signal
    {
        Ok,
        Err,
        KrajServer,
    }
}

